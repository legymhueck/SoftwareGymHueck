/*
 Copyright 2011-2020

 Alfred Wassermann
 Michael Gerhaeuser,
 Carsten Miller,
 Matthias Ehmann,
 Heiko Vogel

 This file is part of the JSXGraph GUI project.
 This code isn't licensed yet.
 */

(function () {

    'use strict';

    var context;

    GUI.Audio = {
        /**
         * List of available sounds.
         * @type Object
         */
        sounds: {
                    'click': new Howl({urls: ['audio/click.mp3', 'audio/click.ogg']}),
                    'bubble': new Howl({urls: ['audio/bubble.mp3', 'audio/bubble.ogg']}),
                    'plastic': new Howl({urls: ['audio/plastic.mp3', 'audio/plastic.ogg']})
                },
        levels: [0, 0.23, 0.55, 1],

        /**
         * Sound enabled?
         * @type Boolean
         * @default true
         */
        enabled: true,

        init: function () {
            var s;
            for (s in this.sounds) if (this.sounds.hasOwnProperty(s)) {
                this.sounds[s].autoplay = true;
                this.sounds[s].loop = false;
            }
        },

        play: function (what) {
            this.sounds[what].volume(this.levels[GUI.Settings.get('volume')]);
            this.sounds[what].play();
        },

        click: function() {
            this.sounds.click.volume(this.levels[GUI.Settings.get('volume')] * 0.23);
            this.sounds.click.play();
            this.vibrate(20);
        }
    };

    /**
     * Browser independent vibrate function.
     */
    GUI.Audio.vibrate = (function () {
        if (navigator.vibrate) {
            return function (dur) {
                if (GUI.Settings.get('vibrate')) {
                    return navigator.vibrate(dur);
                }
            };
        }

        if (navigator.mozVibrate) {
            return function (dur) {
                if (GUI.Settings.get('vibrate')) {
                    return navigator.mozVibrate(dur);
                }
            };
        }

        if (navigator.webkitVibrate) {
            return function (dur) {
                if (GUI.Settings.get('vibrate')) {
                    return navigator.webkitVibrate(dur);
                }
            };
        }

        if (navigator.oVibrate) {
            return function (dur) {
                if (GUI.Settings.get('vibrate')) {
                    return navigator.oVibrate(dur);
                }
            };
        }

        if (navigator.msVibrate) {
            return function (dur) {
                if (GUI.Settings.get('vibrate')) {
                    return navigator.msVibrate(dur);
                }
            };
        }

        return function (dur) {
        };
    }());

}());
