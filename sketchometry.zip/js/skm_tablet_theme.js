JXG.Options = JXG.merge(JXG.Options, {

    //renderer: 'canvas',
    device: 'tablet',
    opacityLevel: 0.5,
    sensitive_area: 20,
    lastRegPolCorners: 4,

    lastSliderStart: -10,
    lastSliderEnd: 10,
    lastSliderIni: 1,

    board: {
        minimizeReflow: 'svg', //'all', // 'svg', 'all', 'none'
        zoom: {
            enabled: true,
            wheel: true,
            needShift: true,
            pinchHorizontal: false,
            pinchVertical: false,
        },
        pan: {
            needShift: true,
            needTwoFingers: true,
            enabled: true
        },

        selection: {
            enabled: false
        },

        defaultAxes: {
            x: {
                ticks: {
                    label: {
                        display: 'html',
                        cssStyle: 'background-color: rgba(255, 255, 255, 0.7)'
                    }
                }
            },
            y: {
                ticks: {
                    label: {
                        display: 'html',
                        cssStyle: 'background-color: rgba(255, 255, 255, 0.7)'
                    }
                }
            }
        }

    },

    elements: {
        strokeColor: '#000000',
        strokeOpacity: 1,
        strokeWidth: 5,

        fillColor: '#000000',
        fillOpacity: 0.5,

        highlightStrokeColor: '#000000',
        highlightStrokeOpacity: 0.75,
        highlightStrokeWidth: 8,

        highlightFillColor: '#000000',
        highlightFillOpacity: 0.25,

        transitionDuration: 250
    },

    layer: {
        numlayers: 20, // only important in SVG
        text: 9,
        point: 9,
        glider: 9,
        arc: 8,
        line: 7,
        circle: 6,
        curve: 5,
        turtle: 5,
        polygon: 3,
        sector: 3,
        angle: 3,
        integral: 3,
        axis: 2,
        ticks: 1,
        grid: 1,
        image: 0,
        trace: 0
    },

    angle: {
        strokeColor: '#999999',
        strokeOpacity: 1,
        strokeWidth: 4,

        fillColor: '#cccccc',
        fillOpacity: 0.15,

        highlightStrokeColor: '#666666',
        highlightStrokeOpacity: 1,
        highlightStrokeWidth: 5,

        highlightFillColor: '#cccccc',
        highlightFillOpacity: 0.25,

        radius: 1,

        orthotype: 'sectordot',

        dot: {
            visible: false,

            size: 2,

            strokeColor: '#999999',
            strokeOpacity: 1,
            strokeWidth: 2,

            fillColor: '#999999',
            fillOpacity: 1,

            highlightStrokeColor: '#666666',
            highlightStrokeOpacity: 1,
            highlightStrokeWidth: 4,

            highlightFillColor: '#666666',
            highlightFillOpacity: 1,

            face: 'o',
            withLabel: false,
            name: ''
        },
    },


    axis: {

        strokeColor: '#666666',
        strokeOpacity: 1,
        strokeWidth: 2,

        fillColor: '#666666',
        fillOpacity: 1,

        highlightStrokeColor: '#666666',
        highlightStrokeOpacity: 1,
        highlightStrokeWidth: 2,

        highlightFillColor: '#666666',
        highlightFillOpacity: 1,

        lastArrow: {
            type: 1,
            size: 6
        },

        ticks: {
            strokeWidth: 2,
            strokeColor: '#cccccc',
            strokeOpacity: 1,
            label: {
                fontSize: 14,
                display: 'internal'
            }
        },
        label: {
            position: 'urt',
            offset: [-15, 30],
            display: 'internal'
        }
    },

    bisector: {
        strokeColor: '#666666',
        strokeOpacity: 1,
        strokeWidth: 5,

        fillColor: '#666666',
        fillOpacity: 1,

        highlightStrokeColor: '#333333',
        highlightStrokeOpacity: 1,
        highlightStrokeWidth: 8,

        highlightFillColor: '#333333',
        highlightFillOpacity: 1
    },

    circle: {
        strokeColor: '#6699ff',
        strokeOpacity: 1,
        strokeWidth: 5,

        fillColor: 'none',
        fillOpacity: 0,

        highlightStrokeColor: '#3366cc',
        highlightStrokeOpacity: 1,
        highlightStrokeWidth: 8,

        highlightFillColor: '#6699ff',
        highlightFillOpacity: 0,

        center: {
            visible: false,
            withLabel: false,
            fixed: false,
            name: '',

            size: 5,

            strokeColor: '#ff0000',
            strokeOpacity: 1,
            strokeWidth: 5,

            fillColor: '#ff3366',
            fillOpacity: 1,

            highlightStrokeColor: '#cc3366',
            highlightStrokeOpacity: 1,
            highlightStrokeWidth: 10,

            highlightFillColor: '#cc3366',
            highlightFillOpacity: 1,

            traceAttributes: {
                size: 1,
                strokeWidth: 2
            }
        }
    },
    circumcircle: {
        strokeColor: '#666666',
        strokeOpacity: 1,
        strokeWidth: 5,

        fillColor: '#666666',
        fillOpacity: 1,

        highlightStrokeColor: '#333333',
        highlightStrokeOpacity: 1,
        highlightStrokeWidth: 8,

        highlightFillColor: '#333333',
        highlightFillOpacity: 1,

        center: {
            visible: true,
            fixed: false,
            withLabel: false,
            name: '',

            size: 5,

            strokeColor: '#999999',
            strokeOpacity: 1,
            strokeWidth: 5,

            fillColor: '#999999',
            fillOpacity: 1,

            highlightStrokeColor: '#666666',
            highlightStrokeOpacity: 1,
            highlightStrokeWidth: 10,

            highlightFillColor: '#666666',
            highlightFillOpacity: 1
        }
    },
    curve: {
        strokeColor: '#669966',
        strokeOpacity: 1,
        strokeWidth: 4,

        fillColor: 'none',
        fillOpacity: 0,

        highlightStrokeColor: '#336633',
        highlightStrokeOpacity: 1,
        highlightStrokeWidth: 6,

        highlightFillColor: '#336633',
        highlightFillOpacity: 0
    },

    glider : {
        size: 5,

        strokeColor: '#ff9900',
        strokeOpacity: 1,
        strokeWidth: 5,

        fillColor: '#ff9900',
        fillOpacity: 1,

        highlightStrokeColor: '#ff6600',
        highlightStrokeOpacity: 1,
        highlightStrokeWidth: 10,

        highlightFillColor: '#ff6600',
        highlightFillOpacity: 1
    },

    grid: {
        strokeColor: '#cccccc',
        strokeOpacity: 1,
        strokeWidth: 1,

        fillColor: '#cccccc',
        fillOpacity: 1,

        highlightStrokeColor: '#cccccc',
        highlightStrokeOpacity: 1,
        highlightStrokeWidth: 1,

        highlightFillColor: '#cccccc',
        highlightFillOpacity: 1
    },

    intersection: {
        size: 5,

        strokeColor: '#999999',
        strokeOpacity: 1,
        strokeWidth: 5,

        fillColor: '#999999',
        fillOpacity: 1,

        highlightStrokeColor: '#666666',
        highlightStrokeOpacity: 1,
        highlightStrokeWidth: 10,

        highlightFillColor: '#666666',
        highlightFillOpacity: 1
    },

    label: {
        strokeColor: '#333333',
        strokeOpacity: 1,

        fillColor: '#333333',
        fillOpacity: 1,

        highlightStrokeColor: '#000000',
        highlightStrokeOpacity: 1,

        highlightFillColor: '#000000',
        highlightFillOpacity: 1,

        offset: [15, 15]
    },

    line: {
        strokeColor: '#6699ff',
        strokeOpacity: 1,
        strokeWidth: 5,

        fillColor: '#6699ff',
        fillOpacity: 1,

        highlightStrokeColor: '#3366cc',
        highlightStrokeOpacity: 1,
        highlightStrokeWidth: 8,

        highlightFillColor: '#3366cc',
        highlightFillOpacity: 1
    },

    midpoint: {
        size: 5,

        strokeColor: '#999999',
        strokeOpacity: 1,
        strokeWidth: 5,

        fillColor: '#999999',
        fillOpacity: 1,

        highlightStrokeColor: '#666666',
        highlightStrokeOpacity: 1,
        highlightStrokeWidth: 10,

        highlightFillColor: '#666666',
        highlightFillOpacity: 1
    },

    normal: {
        strokeColor: '#666666',
        strokeOpacity: 1,
        strokeWidth: 5,

        fillColor: '#666666',
        fillOpacity: 1,

        highlightStrokeColor: '#333333',
        highlightStrokeOpacity: 1,
        highlightStrokeWidth: 8,

        highlightFillColor: '#333333',
        highlightFillOpacity: 1
    },

    parallel: {
        strokeColor: '#666666',
        strokeOpacity: 1,
        strokeWidth: 5,

        fillColor: '#666666',
        fillOpacity: 1,

        highlightStrokeColor: '#333333',
        highlightStrokeOpacity: 1,
        highlightStrokeWidth: 8,

        highlightFillColor: '#333333',
        highlightFillOpacity: 1
    },

    perpendicular: {
        strokeColor: '#666666',
        strokeOpacity: 1,
        strokeWidth: 5,

        fillColor: '#666666',
        fillOpacity: 1,

        highlightStrokeColor: '#333333',
        highlightStrokeOpacity: 1,
        highlightStrokeWidth: 8,

        highlightFillColor: '#333333',
        highlightFillOpacity: 1
    },

    perpendicularsegment: {
        strokeColor: '#666666',
        strokeOpacity: 1,
        strokeWidth: 5,

        fillColor: '#666666',
        fillOpacity: 1,

        highlightStrokeColor: '#333333',
        highlightStrokeOpacity: 1,
        highlightStrokeWidth: 8,

        highlightFillColor: '#333333',
        highlightFillOpacity: 1,

        point: {
            visible: true,

            size: 5,

            strokeColor: '#999999',
            strokeOpacity: 1,
            strokeWidth: 5,

            fillColor: '#999999',
            fillOpacity: 1,

            highlightStrokeColor: '#666666',
            highlightStrokeOpacity: 1,
            highlightStrokeWidth: 10,

            highlightFillColor: '#666666',
            highlightFillOpacity: 1
        }
    },

    point: {
        size: 5,

        strokeColor: '#ff3366',
        strokeOpacity: 1,
        strokeWidth: 5,

        fillColor: '#ff3366',
        fillOpacity: 1,

        highlightStrokeColor: '#cc3366',
        highlightStrokeOpacity: 1,
        highlightStrokeWidth: 10,

        highlightFillColor: '#cc3366',
        highlightFillOpacity: 1,

        traceAttributes: {
            size: 1,
            strokeWidth: 2
        },

        // snap on majorTicks

        snapX: -1,
        snapY: -1
    },


    polygon: {
        fillColor: '#ffcc00',
        fillOpacity: 0.25,

        highlightFillColor: '#ffcc00',
        highlightFillOpacity: 0.5,

        hasInnerPoints: true,

        borders: {
            strokeColor: '#ffcc33',
            strokeOpacity: 1,
            strokeWidth: 5,

            fillColor: '#ffcc33',
            fillOpacity: 1,

            highlightStrokeColor: '#cc9933',
            highlightStrokeOpacity: 1,
            highlightStrokeWidth: 8,

            highlightFillColor: '#cc0033',
            highlightFillOpacity: 1
        }
    },

    precision: {
        touchMax: Infinity
    },
    regularpolygon: {
        fillColor: '#ffcc00',
        fillOpacity: 0.25,

        highlightFillColor: '#ffcc00',
        highlightFillOpacity: 0.5,

        hasInnerPoints: true,

        borders: {
            strokeColor: '#ffcc33',
            strokeOpacity: 1,
            strokeWidth: 5,

            fillColor: '#ffcc33',
            fillOpacity: 1,

            highlightStrokeColor: '#cc9933',
            highlightStrokeOpacity: 1,
            highlightStrokeWidth: 8,

            highlightFillColor: '#cc0033',
            highlightFillOpacity: 1
        },
        vertices: {
            layer: 9,

            withLabel: true,

            size: 5,

            strokeColor: '#999999',
            strokeOpacity: 1,
            strokeWidth: 5,

            fillColor: '#999999',
            fillOpacity: 1,

            highlightStrokeColor: '#666666',
            highlightStrokeOpacity: 1,
            highlightStrokeWidth: 10,

            highlightFillColor: '#666666',
            highlightFillOpacity: 1
        }
    },
    sector: {
        strokeColor: '#6699ff',
        strokeOpacity: 1,
        strokeWidth: 0,

        fillColor: '#6699ff',
        fillOpacity: 0.25,

        highlightStrokeColor: '#3366cc',
        highlightStrokeOpacity: 1,
        highlightStrokeWidth: 0,

        highlightFillColor: '#6699ff',
        highlightFillOpacity: 0.5,

        highlightOnSector: false,

        arc: {
            visible: true,

            strokeColor: '#6699ff',
            strokeOpacity: 1,
            strokeWidth: 5,

            fillColor: 'none',
            fillOpacity: 0,

            highlightStrokeColor: '#3366cc',
            highlightStrokeOpacity: 1,
            highlightStrokeWidth: 8,

            highlightFillColor: 'none',
            highlightFillOpacity: 0.5
        }
    },

    segment: {
        label: {
            position: 'bot',
            offsets: [0,-12]
        }
    },

    slider: {
        size: 10,

        strokeColor: '#666666',
        strokeOpacity: 1,
        strokeWidth: 0,

        fillColor: '#666666',
        fillOpacity: 1,

        highlightStrokeColor: '#333333',
        highlightStrokeOpacity: 1,
        highlightStrokeWidth: 0,

        highlightFillColor: '#333333',
        highlightFillOpacity: 1,

        face: '<>',

        ticks: {
            tickEndings: [1, 1],
            minTicksDistance: 15,

            strokeColor: '#999999',
            strokeOpacity: 1,
            strokeWidth: 2,

            fillColor: '#999999',
            fillOpacity: 1,

            highlightStrokeColor: '#666666',
            highlightStrokeOpacity: 1,
            highlightStrokeWidth: 2,

            highlightFillColor: '#666666',
            highlightFillOpacity: 1,

            needsRegularUpdate: true,
            fixed: false
        },
        baseline: {
            strokeColor: '#999999',
            strokeOpacity: 1,
            strokeWidth: 2,

            fillColor: '#999999',
            fillOpacity: 1,

            highlightStrokeColor: '#666666',
            highlightStrokeOpacity: 1,
            highlightStrokeWidth: 2,

            highlightFillColor: '#666666',
            highlightFillOpacity: 1,

            needsRegularUpdate: true,
            fixed: false
        },
        highline: {
            strokeColor: '#666666',
            strokeOpacity: 1,
            strokeWidth: 3,

            fillColor: '#666666',
            fillOpacity: 1,

            highlightStrokeColor: '#333333',
            highlightStrokeOpacity: 1,
            highlightStrokeWidth: 3,

            highlightFillColor: '#333333',
            highlightFillOpacity: 1,

            needsRegularUpdate: true
        },
        point1: {
            fixed: false,
            needsRegularUpdate: true,
            snapToGrid: true,
            strokeColor: '#444444',
            highlightStrokeColor: '#444444',
            fillColor: '#444444',
            highlightFillColor: '#444444',
            strokeOpacity: 0.5,
            highlightStrokeOpacity: 0.5,
            size: 3
        },
        point2: {
            fixed: false,
            needsRegularUpdate: true,
            snapToGrid: true,
            strokeColor: '#444444',
            highlightStrokeColor: '#444444',
            fillColor: '#444444',
            highlightFillColor: '#444444',
            strokeOpacity: 0.5,
            highlightStrokeOpacity: 0.5,
            size: 3
        }
    },

    slopetriangle: {
        fillColor: '#ffcc00',
        fillOpacity: 0.25,

        highlightFillColor: '#ffcc00',
        highlightFillOpacity: 0.5,

        borders: {
            lastArrow: {
                    type: 2,
                    size: 4
            }
        },


        glider: {
            visible: true,
            size: 2,

            strokeColor: '#999999',
            strokeOpacity: 1,
            strokeWidth: 5,

            fillColor: '#999999',
            fillOpacity: 1,

            highlightStrokeColor: '#666666',
            highlightStrokeOpacity: 1,
            highlightStrokeWidth: 10,

            highlightFillColor: '#666666',
            highlightFillOpacity: 1
        },

        /*
        baseline: {
            visible: false
        },

        basepoint: {
            visible: true
        },

        tangent: {
            visible: false
        },
        */
        toppoint: {
            visible: true,
            size: 2,

            strokeColor: '#999999',
            strokeOpacity: 1,
            strokeWidth: 5,

            fillColor: '#999999',
            fillOpacity: 1,

            highlightStrokeColor: '#666666',
            highlightStrokeOpacity: 1,
            highlightStrokeWidth: 10,

            highlightFillColor: '#666666',
            highlightFillOpacity: 1
        }
    },

    tapemeasure: {
        strokeColor: '#666666',
        strokeOpacity: 1,
        strokeWidth: 2,

        fillColor: '#666666',
        fillOpacity: 1,

        highlightStrokeColor: '#333333',
        highlightStrokeOpacity: 1,
        highlightStrokeWidth: 3,

        highlightFillColor: '#333333',
        highlightFillOpacity: 1,

        point1: {
            snapToPoints: true,
            attractorUnit: 'screen',
            attractorDistance: 20,

            size: 10,

            strokeColor: '#333333',
            strokeOpacity: 1,
            strokeWidth: 5,

            fillColor: 'none',
            fillOpacity: 0,

            highlightStrokeColor: '#000000',
            highlightStrokeOpacity: 1,
            highlightStrokeWidth: 8,

            highlightFillColor: 'none',
            highlightFillOpacity: 0.5
        },
        point2: {
            snapToPoints: true,
            attractorUnit: 'screen',
            attractorDistance: 20,

            size: 10,

            strokeColor: '#333333',
            strokeOpacity: 1,
            strokeWidth: 5,

            fillColor: 'none',
            fillOpacity: 0,

            highlightStrokeColor: '#000000',
            highlightStrokeOpacity: 1,
            highlightStrokeWidth: 8,

            highlightFillColor: 'none',
            highlightFillOpacity: 0.5
        },
        ticks: {
            strokeColor: '#333333',
            strokeOpacity: 1,
            strokeWidth: 2,

            fillColor: '#333333',
            fillOpacity: 1,

            highlightStrokeColor: '#000000',
            highlightStrokeOpacity: 1,
            highlightStrokeWidth: 2,

            highlightFillColor: '#000000',
            highlightFillOpacity: 1
        }
    },

    text: {
        fontSize: 32,
        strokeColor: '#666666',
        strokeOpacity: 1,

        highlightStrokeColor: '#666666',
        highlightStrokeOpacity: 1
    },

    trunclen: 2


});

if (JXG.isAndroid() || JXG.isApple()) {
    JXG.Options.curve.RDPsmoothing = false;
    JXG.Options.curve.numberPointsHigh = 600;
    JXG.Options.curve.numberPointsLow = 100;
    JXG.Options.curve.doAdvancedPlot = true;
}
