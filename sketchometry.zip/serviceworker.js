var VERSION = 'sketchometry_v1.5.2';

var filesToCache;

// Release
// Produce this list with
//      find . -type f | sed "s/\.\//\t'/; s/$/',/"
// in bin/GUI after extracting a working version.
filesToCache = [
    'fonts/sketchometry-light.woff',
    'fonts/FiraSans-Regular.woff',
    'fonts/sketchometry-light.svg',
    'fonts/FiraSans-Regular.otf',
    'pics/sketchometry_chrome_16x16_blue.png',
    'pics/sketchometry_chrome_128x128_blue.png',
    'pics/sketchometry_chrome_144x144_blue.png',
    'pics/sketchometry_152x152_green.png',
    'pics/sketchometry_120x120_green.png',
    'pics/sketchometry_favicon_blue.ico', // There seem to be issues in some browsers caching it.
    'pics/sketchometry_76x76_green.png',
    'pics/sketchometry_60x60_green.png',
    'pics/preloader.gif',
    'pics/cloud-logos.png',
    'Info.plist',
    '3dparty/jQuery/jquery.draggableTouch.js',
    '3dparty/jQuery/jquery-3.2.1.min.js',
    '3dparty/jQuery/jquery.jsonp.js',
    '3dparty/jQuery/jquery-3.2.1.js',
    '3dparty/filesaver/Blob.js',
    '3dparty/filesaver/FileSaver.js',
    '3dparty/jszip/jszip-load.min.js',
    '3dparty/jszip/jszip-deflate.min.js',
    '3dparty/jszip/jszip.min.js',
    '3dparty/howler/howler.min.js',
    '3dparty/howler/howler.js',
    'audio/click.mp3',
    'audio/bubble.mp3',
    'audio/plastic.ogg',
    'audio/plastic.mp3',
    'audio/bubble.ogg',
    'audio/click.ogg',
    'js/GeonextReader.js',
    'js/ext_ecma.js',
    'js/url.js',
    'js/sketch.js',
    'js/SketchReader.js',
    'js/jsxgraph.js',
    'js/ext_jquery.js',
    'js/gui.js',
    'js/sk.js',
    'js/skm_tablet_theme.js',
    'serviceworker.js',
    'config.js',
    'css/gallery-small.css',
    'css/gallery-general.css',
    'css/gui-normal.css',
    'css/gui-small.css',
    //'serviceworker.js', // not allowed
    'index.html',
    'manifest.json'
];

self.addEventListener('install', event => {
    console.log('sketchometry: Attempting to install service worker and cache static assets');

    event.waitUntil(
        caches.open(VERSION)
        .then(cache => {
            return cache.addAll(filesToCache);
        })
    );
});

self.addEventListener('fetch', function(event) {
    // console.log('Fetch event for ', event.request.url);
    event.respondWith(
        caches.match(event.request).then(function(response) {
            if (response) {
                // console.log('Found ', event.request.url, ' in cache');
                return response;
            }
            // console.log('Network request for ', event.request.url);
            return fetch(event.request)
                    .then(function(response) {
                        // TODO 5 - Respond with custom 404 page
                        return caches.open(VERSION).then(function(cache) {
                            //console.log('PUT ', event.request.url, ' in cache');
                            if (event.request.url.indexOf('test') < 0) {
                                cache.put(event.request.url, response.clone());
                            }
                            return response;
                        });
                    });


        }).catch(function(error) {
            console.log("sketchometry is OFFLINE - no problem");
            // TODO 6 - Respond with custom offline page
        })
    );
});

self.addEventListener('activate', function(event) {
    console.log('sketchometry: Activating new service worker...');

    var cacheWhitelist = [VERSION];

    event.waitUntil(
        caches.keys().then(function(cacheNames) {
            return Promise.all(
                cacheNames.map(function(cacheName) {
                    console.log(cacheName, cacheName.indexOf('sketchometry'), cacheWhitelist.indexOf(cacheName));
                    if (cacheName.indexOf('sketchometry') === 0 && cacheWhitelist.indexOf(cacheName) === -1) {
                        return caches.delete(cacheName);
                    }
                })
            );
        })
    );
});
